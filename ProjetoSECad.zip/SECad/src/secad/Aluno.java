package secad;

public class Aluno {
    
    
}
