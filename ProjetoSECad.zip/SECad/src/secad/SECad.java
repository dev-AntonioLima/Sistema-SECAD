package secad;
public class SECad {
    
public static void main(String[] args) {

    }
    
}
