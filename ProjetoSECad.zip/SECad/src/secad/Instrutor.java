package secad;

public class Instrutor {
    
}
