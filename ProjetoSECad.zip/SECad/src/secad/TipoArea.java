package secad;

public enum TipoArea {
    
}
